<div id="{{uc_id}}" class="ue_line_chart_wrapper">
  <div id="{{uc_id}}_line" class="ue_line_chart"></div>
</div>
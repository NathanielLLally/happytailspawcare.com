{% if item_color_type == "custom" %}
  {% if line_color %}
    '{{ line_color }}',
  {% else %}
    '#374b66',
  {% endif %}
{% endif %}
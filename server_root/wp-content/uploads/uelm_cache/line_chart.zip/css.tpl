#{{uc_id}}{
  position: relative;
  display:flex;
  flex-direction:row;
}
#{{uc_id}} .ue_line_chart{
  position:relative;
  max-width:100%;
  width:{{width}};
  height:{{height}};
}
@media (max-width: 1024px){
  #{{uc_id}} .ue_line_chart{
    width:{{width_tablet}};
    height:{{height_tablet}};
  }
}
@media (max-width: 767px){
  #{{uc_id}} .ue_line_chart{
    width:{{width_mobile}};
    height:{{height_mobile}};
  }
}
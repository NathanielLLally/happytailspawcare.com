jQuery(document).ready(function(){
  
  function getResponsiveChartArea() {
    const width = window.innerWidth;
    if (width <= 767) return "{% if chart_area_mobile_nounit %}{{chart_area_mobile_nounit}}{% else %}{{chart_area_nounit}}{% endif %}%";
    else if (width <= 1023) return "{% if chart_area_tablet_nounit %}{{chart_area_tablet_nounit}}{% else %}{{chart_area_nounit}}{% endif %}%";
    else return "{{chart_area_nounit}}%";
  }

  function drawChart_{{uc_id}}() {
    var data = google.visualization.arrayToDataTable([
      ['{{x_title}}', '{{y_title}}'],
      {{put_items()}}
    ]);

    var options = {      
      {% if show_title == "true" %}
        title: '{{title}}',
        titleTextStyle: {
          {% if font_family %}fontName: '{{font_family|raw}}',{% endif %}
          {% if font_size %}fontSize: {{font_size_nounit}},{% endif %}
          {% if title_color %}color: '{{title_color}}',{% endif %}
          bold: {{title_bold}},
        },
      {% endif %}
        {% if text_font_family %}fontName: '{{text_font_family|raw}}',{% endif %}
        {% if text_font_size %}fontSize: {{text_font_size_nounit}},{% endif %}
        width: '100%',
        height: '100%',
        backgroundColor: 'transparent',
        hAxis: {
          {% if minimum_range_x %}minValue: {{minimum_range_x}},{% endif %}
          {% if maximum_value_x %}maxValue: {{maximum_value_x}},{% endif %}
          title: '{{x_axis_label|raw}}', // Horizontal axis title
          gridlines: { {% if gridlines_x %}count: {{gridlines_x}},{% endif %} {% if gridlines_color_x %}color: '{{gridlines_color_x}}'{% endif %} },
          format: '{{value_format_x}}',
          textStyle: {
            {% if text_color_x %}color: '{{text_color_x}}',{% endif %}
          },
          titleTextStyle: {
            {% if axis_title_color_x %}color: '{{axis_title_color_x}}',{% endif %}
            {% if axis_title_font_size_x %}fontSize: {{axis_title_font_size_x}},{% endif %}
            {% if axis_title_bold_x %}bold: {{axis_title_bold_x}},{% endif %}
          }
        },
        vAxis: {
          {% if minimum_range %}minValue: {{minimum_range}},{% endif %}
          {% if maximum_value %}maxValue: {{maximum_value}},{% endif %}
          title: '{{y_axis_label|raw}}', // Vertical axis title
          gridlines: { {% if gridlines %}count: {{gridlines}},{% endif %} {% if gridlines_color %}color: '{{gridlines_color}}'{% endif %} },
          format: '{{value_format}}',
          textStyle: {
            {% if text_color_y %}color: '{{text_color_y}}',{% endif %}
          },
          titleTextStyle: {
            {% if axis_title_color_y %}color: '{{axis_title_color_y}}',{% endif %}
            {% if axis_title_font_size_y %}fontSize: {{axis_title_font_size_y}},{% endif %}
            {% if axis_title_bold_y %}bold: {{axis_title_bold_y}},{% endif %}
          }
        },
        curveType: '{{curve_type}}',
        {% if line_width_nounit %}lineWidth: {{line_width_nounit}},{% endif %}
        {% if data_point_size_nounit %}pointSize: {{data_point_size_nounit}},{% endif %}
        pointShape: '{{data_point_shape}}',
        {% if show_legend != "none" %}
        legend: { 
          position: '{{show_legend}}',
          alignment: '{{legend_alignment}}',
          textStyle: {
            {% if legend_font_family %}fontName: '{{legend_font_family|raw}}',{% endif %}
            {% if legend_color %}color: '{{legend_color}}',{% endif %}
            {% if legend_font_size %}fontSize: {{legend_font_size}},{% endif %}
            bold: {{legend_bold}},
          }
        },
        {% else %}
            legend:'none',
        {% endif %}
        tooltip: {
             trigger: 'focus', 
             textStyle: {
                 {% if tt_font_family %}fontName: '{{tt_font_family|raw}}',{% endif %}
                 {% if tt_font_size_nounit %}fontSize: {{tt_font_size_nounit}},{% endif %}
                 {% if tt_text_color %}color: '{{tt_text_color}}',{% endif %}
                 bold: {{tt_bold}}
             }, 
             showColorCode: {{show_tt_color}}
        },
        chartArea: { width: getResponsiveChartArea(), height: getResponsiveChartArea() },
        {% if item_color_type == "custom" %} colors: [{{put_items2()}}] {% endif %}
    };
    var chart = new google.visualization.LineChart(document.getElementById('{{uc_id}}_line'));

    chart.draw(data, options);
  }

  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart_{{uc_id}});
                  
  function debounce(func, wait) {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), wait);
    };
  }
                  
  window.addEventListener('resize', debounce(drawChart_{{uc_id}}, 200));
  
});